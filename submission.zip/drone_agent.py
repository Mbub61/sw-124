"""Per-type param routing: apply config04's params only to the types it helped
(village/open/warehouse), keep champion defaults elsewhere. Routes by the
champion's own runtime XGBoost classification (self.base._map_prediction_label).

Drop-in drone_agent.py over a param_v1-style base (_param_base reads SW_* via _P).
Sets SW_* env (read by _P at act time) + VIS attrs each step based on last
classification. Single-threaded per worker, one seed at a time -> env switching safe.
"""
import os
import numpy as np
from _param_base import DroneFlightController as _Base

HELPED = set(x for x in os.environ.get("SW_HELPED", "village,open,warehouse").split(",") if x)

# config04 (sweep find) — helped village/open/warehouse
C04 = {"MTN_DIST": "39.582", "ARM_MIN": "10.947", "ARM_MAX": "17.238",
       "LAND_TRIG": "5.135", "START_GUARD": "5.978", "ROT_SCAN": "158"}
C04_VIS = (0.566, 0.44)
# champion defaults — for city/mountain/forest (where config04 hurt)
DEF = {"MTN_DIST": "45.0", "ARM_MIN": "12.0", "ARM_MAX": "18.0",
       "LAND_TRIG": "4.0", "START_GUARD": "3.5", "ROT_SCAN": "100"}
DEF_VIS = (0.55, 0.35)


def _apply(vals, vis, base):
    for k, v in vals.items():
        os.environ["SW_" + k] = v
    base._goal_visible_enter_threshold = vis[0]
    base._goal_visible_exit_threshold = vis[1]


class DroneFlightController:
    def __init__(self):
        # start in default regime so __init__/first reset read champ defaults
        for k, v in DEF.items():
            os.environ["SW_" + k] = v
        self.base = _Base()

    def reset(self):
        _apply(DEF, DEF_VIS, self.base)
        self.base.reset()

    def act(self, observation):
        lbl = getattr(self.base, "_map_prediction_label", None)
        if lbl in HELPED:
            _apply(C04, C04_VIS, self.base)
        else:
            _apply(DEF, DEF_VIS, self.base)
        return self.base.act(observation)
